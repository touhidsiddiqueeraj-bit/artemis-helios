/**
 * ╔══════════════════════════════════════════════════════════════════════╗
 * ║  HELIOS DATA LOGGER  —  v1.0                                        ║
 * ║  ESP32-S3 N16R8 · TSL2591 · OV2640 · LittleFS                      ║
 * ║                                                                      ║
 * ║  Logs irradiance (TSL2591) + sky blue channel (OV2640) to           ║
 * ║  internal flash every 10 s during daylight (lux-triggered).         ║
 * ║  Web dashboard + captive portal + mDNS (helios.local).              ║
 * ║                                                                      ║
 * ║  Hussain Touhid Siddiquee · Leading University Sylhet · 2026        ║
 * ╚══════════════════════════════════════════════════════════════════════╝
 *
 * WIRING
 * ──────
 * TSL2591  SDA → GPIO 8   SCL → GPIO 9   VIN → 3.3V   GND → GND
 * OV2640   — on-board (XIAO ESP32S3 Sense or equivalent embedded module)
 * SD card  — on-board embedded port (not used in this build; LittleFS only)
 *
 * LIBRARIES REQUIRED (install via Arduino Library Manager)
 * ─────────────────────────────────────────────────────────
 * - Adafruit TSL2591 Library  (Adafruit)
 * - Adafruit Unified Sensor   (Adafruit)
 * - ESP32 Arduino Core ≥ 2.0  (includes LittleFS, WiFi, mDNS, camera)
 *
 * PARTITION SCHEME
 * ─────────────────
 * Use "Huge APP (3MB No OTA / 1MB SPIFFS)" or custom partition with
 * at least 4MB for data. In Arduino IDE: Tools → Partition Scheme →
 * "Default 4MB with spiffs" then we use LittleFS on that data partition.
 *
 * FILESYSTEM SIZE
 * ────────────────
 * N16R8 has 16MB flash. Default Arduino partition gives ~1.5MB for SPIFFS/
 * LittleFS. For 14 days of data (~3MB), select a partition scheme with at
 * least 4MB data partition, or use the custom partitions.csv below.
 *
 * ACCESS
 * ───────
 * 1. Power on ESP32-S3
 * 2. Connect to WiFi AP: "Helios-Logger" (password: helios2026)
 * 3. Any HTTP request triggers captive portal → redirects to dashboard
 * 4. Or navigate directly to http://helios.local or http://192.168.4.1
 */

// ═══════════════════════════════════════════════════════════════════════════
//  INCLUDES
// ═══════════════════════════════════════════════════════════════════════════
#include <Arduino.h>
#include <Wire.h>
#include <WiFi.h>
#include <WebServer.h>
#include <ESPmDNS.h>
#include <LittleFS.h>
#include <time.h>

#include "Adafruit_TSL2591.h"
#include "Adafruit_Sensor.h"

// OV2640 via ESP32 camera driver
#include "esp_camera.h"
#include "camera_pins.h"   // see camera_pins.h tab

// Dashboard HTML (stored in PROGMEM to save RAM)
#include "dashboard.h"

// ═══════════════════════════════════════════════════════════════════════════
//  CONFIGURATION
// ═══════════════════════════════════════════════════════════════════════════

// WiFi Access Point
#define AP_SSID        "Helios-Logger"
#define AP_PASSWORD    "helios2026"
#define AP_IP          "192.168.4.1"

// mDNS hostname  →  http://helios.local
#define MDNS_HOSTNAME  "helios"

// Logging
#define SAMPLE_INTERVAL_MS   10000UL   // 10 seconds
#define LUX_START_THRESHOLD  20.0f     // start logging above this
#define LUX_STOP_THRESHOLD   8.0f      // stop logging below this (hysteresis)
#define DATA_DIR             "/data"
#define MAX_DAYS             14

// TSL2591 I²C pins (change if your board differs)
#define I2C_SDA  8
#define I2C_SCL  9

// Lux → W/m² conversion factor for TSL2591 (broadband, empirical)
// 1 W/m² ≈ 116 lux for AM1.5 solar spectrum (standard approximation)
#define LUX_TO_WM2  (1.0f / 116.0f)

// ═══════════════════════════════════════════════════════════════════════════
//  GLOBALS
// ═══════════════════════════════════════════════════════════════════════════

Adafruit_TSL2591 tsl = Adafruit_TSL2591(2591);
WebServer        server(80);

bool     isLogging      = false;   // lux-triggered logging state
uint32_t lastSampleMs   = 0;
uint32_t uptimeStartMs  = 0;       // millis() when logging started today
uint32_t dayCounter     = 0;       // 0-based day index
char     currentFile[32];          // e.g. /data/day_01.csv

// Live buffer for dashboard chart (last 360 samples = 1 hour)
#define LIVE_BUFFER_SIZE 360
struct Sample {
  uint32_t uptime_ms;
  float    lux;
  float    irradiance_wm2;
  uint8_t  blue_channel;
  uint8_t  tsl_gain;      // 0=low,1=med,2=high,3=max
  uint16_t tsl_integration; // ms
};
Sample   liveBuffer[LIVE_BUFFER_SIZE];
uint16_t liveHead    = 0;
uint16_t liveCount   = 0;
uint32_t totalSamples = 0;

// ═══════════════════════════════════════════════════════════════════════════
//  TSL2591 — AUTO-GAIN CONFIGURATION
// ═══════════════════════════════════════════════════════════════════════════
void configureTSL() {
  // Start with medium gain, 100ms integration
  tsl.setGain(TSL2591_GAIN_MED);
  tsl.setTiming(TSL2591_INTEGRATIONTIME_100MS);
}

/**
 * Auto-adjust TSL2591 gain based on current reading to maximise dynamic range.
 * Returns false if sensor saturated even on lowest gain (full sun — log max).
 */
bool readTSL(float &lux, uint8_t &gainCode, uint16_t &integrationMs) {
  uint32_t lum = tsl.getFullLuminosity();
  uint16_t ir  = lum >> 16;
  uint16_t full = lum & 0xFFFF;

  // If channel saturated, drop gain
  if (full >= 65535 || ir >= 65535) {
    tsl2591Gain_t g = tsl.getGain();
    if (g == TSL2591_GAIN_MAX)       tsl.setGain(TSL2591_GAIN_HIGH);
    else if (g == TSL2591_GAIN_HIGH) tsl.setGain(TSL2591_GAIN_MED);
    else if (g == TSL2591_GAIN_MED)  tsl.setGain(TSL2591_GAIN_LOW);
    // else already at low — sensor truly saturated (direct sun)
    lum  = tsl.getFullLuminosity();
    ir   = lum >> 16;
    full = lum & 0xFFFF;
  }

  // If reading very low, increase gain
  if (full < 100 && ir < 100) {
    tsl2591Gain_t g = tsl.getGain();
    if (g == TSL2591_GAIN_LOW)       tsl.setGain(TSL2591_GAIN_MED);
    else if (g == TSL2591_GAIN_MED)  tsl.setGain(TSL2591_GAIN_HIGH);
    else if (g == TSL2591_GAIN_HIGH) tsl.setGain(TSL2591_GAIN_MAX);
    lum  = tsl.getFullLuminosity();
    ir   = lum >> 16;
    full = lum & 0xFFFF;
  }

  lux = tsl.calculateLux(full, ir);
  if (lux < 0) lux = 0.0f;  // calculateLux returns -1 on error

  // Encode gain for CSV
  switch (tsl.getGain()) {
    case TSL2591_GAIN_LOW:  gainCode = 0; break;
    case TSL2591_GAIN_MED:  gainCode = 1; break;
    case TSL2591_GAIN_HIGH: gainCode = 2; break;
    case TSL2591_GAIN_MAX:  gainCode = 3; break;
    default:                gainCode = 1;
  }

  // Encode integration time
  switch (tsl.getTiming()) {
    case TSL2591_INTEGRATIONTIME_100MS: integrationMs = 100;  break;
    case TSL2591_INTEGRATIONTIME_200MS: integrationMs = 200;  break;
    case TSL2591_INTEGRATIONTIME_300MS: integrationMs = 300;  break;
    case TSL2591_INTEGRATIONTIME_400MS: integrationMs = 400;  break;
    case TSL2591_INTEGRATIONTIME_500MS: integrationMs = 500;  break;
    case TSL2591_INTEGRATIONTIME_600MS: integrationMs = 600;  break;
    default:                            integrationMs = 100;
  }

  return (full < 65535 && ir < 65535);
}

// ═══════════════════════════════════════════════════════════════════════════
//  OV2640 — BLUE CHANNEL EXTRACTION
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Capture one frame and return mean blue channel value (0–255).
 * We use RGB565 format and extract the 5-bit blue field.
 * Returns 0 on camera error.
 */
uint8_t captureBlueChannel() {
  camera_fb_t *fb = esp_camera_fb_get();
  if (!fb) {
    Serial.println("[CAM] Frame capture failed");
    return 0;
  }

  // RGB565: each pixel = 2 bytes
  // Byte 0: RRRRRGGG  Byte 1: GGGBBBBB
  // Blue = lower 5 bits of byte 1, scaled to 0-255: blue8 = (b5 << 3) | (b5 >> 2)
  uint32_t blueSum   = 0;
  uint32_t pixelCount = fb->len / 2;

  // Sample every 4th pixel for speed (still statistically representative)
  for (uint32_t i = 1; i < fb->len; i += 8) {
    uint8_t  b5  = fb->buf[i] & 0x1F;
    uint8_t  b8  = (b5 << 3) | (b5 >> 2);
    blueSum += b8;
  }
  uint32_t sampledPixels = (fb->len / 8) + 1;
  uint8_t  meanBlue      = (uint8_t)(blueSum / sampledPixels);

  esp_camera_fb_return(fb);
  return meanBlue;
}

// ═══════════════════════════════════════════════════════════════════════════
//  LITTLEFS — FILE MANAGEMENT
// ═══════════════════════════════════════════════════════════════════════════

void ensureDataDir() {
  if (!LittleFS.exists(DATA_DIR)) {
    LittleFS.mkdir(DATA_DIR);
    Serial.println("[FS] Created /data directory");
  }
}

/**
 * Open (or create) today's CSV file.
 * File name: /data/day_XX.csv where XX = day number (01–14).
 * Writes CSV header if file is new.
 */
void openDayFile(uint32_t day) {
  snprintf(currentFile, sizeof(currentFile), "%s/day_%02lu.csv", DATA_DIR, day + 1);

  if (!LittleFS.exists(currentFile)) {
    File f = LittleFS.open(currentFile, "w");
    if (f) {
      f.println("uptime_ms,lux,irradiance_wm2,blue_channel,tsl_gain,integration_ms");
      f.close();
      Serial.printf("[FS] Created %s\n", currentFile);
    } else {
      Serial.printf("[FS] ERROR: could not create %s\n", currentFile);
    }
  } else {
    Serial.printf("[FS] Appending to existing %s\n", currentFile);
  }
}

void writeSample(const Sample &s) {
  File f = LittleFS.open(currentFile, "a");
  if (!f) {
    Serial.println("[FS] ERROR: could not open file for append");
    return;
  }
  f.printf("%lu,%.2f,%.4f,%u,%u,%u\n",
    s.uptime_ms,
    s.lux,
    s.irradiance_wm2,
    s.blue_channel,
    s.tsl_gain,
    s.tsl_integration
  );
  f.close();
}

// ═══════════════════════════════════════════════════════════════════════════
//  LIVE BUFFER
// ═══════════════════════════════════════════════════════════════════════════

void pushToLiveBuffer(const Sample &s) {
  liveBuffer[liveHead] = s;
  liveHead = (liveHead + 1) % LIVE_BUFFER_SIZE;
  if (liveCount < LIVE_BUFFER_SIZE) liveCount++;
  totalSamples++;
}

// ═══════════════════════════════════════════════════════════════════════════
//  WEB SERVER — API ENDPOINTS
// ═══════════════════════════════════════════════════════════════════════════

// GET /api/status
void handleStatus() {
  // Filesystem info
  size_t totalBytes = LittleFS.totalBytes();
  size_t usedBytes  = LittleFS.usedBytes();

  // Count logged files
  uint8_t fileCount = 0;
  File root = LittleFS.open(DATA_DIR);
  if (root && root.isDirectory()) {
    File f = root.openNextFile();
    while (f) { fileCount++; f = root.openNextFile(); }
  }

  // Latest sample
  String latestJson = "null";
  if (liveCount > 0) {
    uint16_t idx = (liveHead == 0) ? LIVE_BUFFER_SIZE - 1 : liveHead - 1;
    Sample &ls = liveBuffer[idx];
    char buf[200];
    snprintf(buf, sizeof(buf),
      "{\"uptime_ms\":%lu,\"lux\":%.2f,\"irradiance_wm2\":%.4f,"
      "\"blue_channel\":%u,\"tsl_gain\":%u,\"integration_ms\":%u}",
      ls.uptime_ms, ls.lux, ls.irradiance_wm2,
      ls.blue_channel, ls.tsl_gain, ls.tsl_integration);
    latestJson = String(buf);
  }

  char json[512];
  snprintf(json, sizeof(json),
    "{"
    "\"logging\":%s,"
    "\"day\":%lu,"
    "\"current_file\":\"%s\","
    "\"total_samples\":%lu,"
    "\"lux_start_threshold\":%.1f,"
    "\"lux_stop_threshold\":%.1f,"
    "\"fs_total_kb\":%u,"
    "\"fs_used_kb\":%u,"
    "\"fs_free_kb\":%u,"
    "\"file_count\":%u,"
    "\"latest\":%s"
    "}",
    isLogging ? "true" : "false",
    dayCounter + 1,
    currentFile,
    totalSamples,
    LUX_START_THRESHOLD,
    LUX_STOP_THRESHOLD,
    (unsigned)(totalBytes / 1024),
    (unsigned)(usedBytes  / 1024),
    (unsigned)((totalBytes - usedBytes) / 1024),
    fileCount,
    latestJson.c_str()
  );

  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.send(200, "application/json", json);
}

// GET /api/live  →  last N samples as JSON array
void handleLive() {
  String countParam = server.arg("count");
  uint16_t count = countParam.length() > 0 ? countParam.toInt() : 60;
  if (count > liveCount) count = liveCount;
  if (count > LIVE_BUFFER_SIZE) count = LIVE_BUFFER_SIZE;

  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.setContentLength(CONTENT_LENGTH_UNKNOWN);
  server.send(200, "application/json", "");

  server.sendContent("[");
  for (uint16_t i = 0; i < count; i++) {
    // Read from oldest to newest
    uint16_t idx = (liveHead - count + i + LIVE_BUFFER_SIZE) % LIVE_BUFFER_SIZE;
    Sample &s = liveBuffer[idx];
    char buf[200];
    snprintf(buf, sizeof(buf),
      "{\"t\":%lu,\"lux\":%.2f,\"irr\":%.4f,\"blue\":%u}%s",
      s.uptime_ms, s.lux, s.irradiance_wm2, s.blue_channel,
      (i < count - 1) ? "," : "");
    server.sendContent(buf);
  }
  server.sendContent("]");
}

// GET /api/files  →  list of CSV files with sizes
void handleFiles() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.setContentLength(CONTENT_LENGTH_UNKNOWN);
  server.send(200, "application/json", "");
  server.sendContent("[");

  File root = LittleFS.open(DATA_DIR);
  bool first = true;
  if (root && root.isDirectory()) {
    File f = root.openNextFile();
    while (f) {
      if (!f.isDirectory()) {
        char buf[128];
        snprintf(buf, sizeof(buf),
          "%s{\"name\":\"%s\",\"size\":%u}",
          first ? "" : ",",
          f.name(), (unsigned)f.size());
        server.sendContent(buf);
        first = false;
      }
      f = root.openNextFile();
    }
  }
  server.sendContent("]");
}

// GET /download?file=day_01.csv
void handleDownload() {
  String filename = server.arg("file");
  if (filename.length() == 0) {
    server.send(400, "text/plain", "Missing file parameter");
    return;
  }
  // Sanitise — only allow files in /data/
  String path = String(DATA_DIR) + "/" + filename;
  if (!LittleFS.exists(path)) {
    server.send(404, "text/plain", "File not found");
    return;
  }
  File f = LittleFS.open(path, "r");
  if (!f) {
    server.send(500, "text/plain", "Could not open file");
    return;
  }
  server.sendHeader("Content-Disposition",
    "attachment; filename=\"" + filename + "\"");
  server.streamFile(f, "text/csv");
  f.close();
}

// DELETE /api/delete?file=day_01.csv
void handleDelete() {
  String filename = server.arg("file");
  if (filename.length() == 0) {
    server.send(400, "text/plain", "Missing file parameter");
    return;
  }
  String path = String(DATA_DIR) + "/" + filename;
  if (LittleFS.remove(path)) {
    server.send(200, "application/json", "{\"ok\":true}");
  } else {
    server.send(500, "application/json", "{\"ok\":false}");
  }
}

// DELETE /api/deleteall  →  wipe all day files
void handleDeleteAll() {
  File root = LittleFS.open(DATA_DIR);
  if (root && root.isDirectory()) {
    File f = root.openNextFile();
    while (f) {
      if (!f.isDirectory()) {
        String p = String(DATA_DIR) + "/" + f.name();
        LittleFS.remove(p);
      }
      f = root.openNextFile();
    }
  }
  totalSamples = 0;
  liveCount    = 0;
  liveHead     = 0;
  dayCounter   = 0;
  server.send(200, "application/json", "{\"ok\":true}");
}

// GET /  →  serve dashboard HTML
void handleRoot() {
  server.sendHeader("Cache-Control", "no-cache");
  server.send_P(200, "text/html", DASHBOARD_HTML);
}

// Captive portal: redirect any unknown host to dashboard
void handleCaptivePortal() {
  server.sendHeader("Location", "http://192.168.4.1/", true);
  server.send(302, "text/plain", "");
}

// ═══════════════════════════════════════════════════════════════════════════
//  SETUP
// ═══════════════════════════════════════════════════════════════════════════
void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println("\n╔═══════════════════════════╗");
  Serial.println("║  HELIOS DATA LOGGER v1.0  ║");
  Serial.println("╚═══════════════════════════╝");

  // ── LittleFS ──────────────────────────────────────────────────────────
  if (!LittleFS.begin(true)) {
    Serial.println("[FS] FATAL: LittleFS mount failed");
    while (1) delay(1000);
  }
  Serial.printf("[FS] Mounted. Total: %uKB  Used: %uKB\n",
    (unsigned)(LittleFS.totalBytes() / 1024),
    (unsigned)(LittleFS.usedBytes()  / 1024));
  ensureDataDir();

  // ── TSL2591 ───────────────────────────────────────────────────────────
  Wire.begin(I2C_SDA, I2C_SCL);
  if (!tsl.begin()) {
    Serial.println("[TSL] FATAL: TSL2591 not found — check wiring");
    while (1) delay(1000);
  }
  configureTSL();
  Serial.println("[TSL] TSL2591 initialised");

  // ── OV2640 ────────────────────────────────────────────────────────────
  camera_config_t camCfg;
  camCfg.ledc_channel = LEDC_CHANNEL_0;
  camCfg.ledc_timer   = LEDC_TIMER_0;
  camCfg.pin_d0       = Y2_GPIO_NUM;
  camCfg.pin_d1       = Y3_GPIO_NUM;
  camCfg.pin_d2       = Y4_GPIO_NUM;
  camCfg.pin_d3       = Y5_GPIO_NUM;
  camCfg.pin_d4       = Y6_GPIO_NUM;
  camCfg.pin_d5       = Y7_GPIO_NUM;
  camCfg.pin_d6       = Y8_GPIO_NUM;
  camCfg.pin_d7       = Y9_GPIO_NUM;
  camCfg.pin_xclk     = XCLK_GPIO_NUM;
  camCfg.pin_pclk     = PCLK_GPIO_NUM;
  camCfg.pin_vsync    = VSYNC_GPIO_NUM;
  camCfg.pin_href     = HREF_GPIO_NUM;
  camCfg.pin_sccb_sda = SIOD_GPIO_NUM;
  camCfg.pin_sccb_scl = SIOC_GPIO_NUM;
  camCfg.pin_pwdn     = PWDN_GPIO_NUM;
  camCfg.pin_reset    = RESET_GPIO_NUM;
  camCfg.xclk_freq_hz = 20000000;
  camCfg.pixel_format = PIXFORMAT_RGB565;
  camCfg.frame_size   = FRAMESIZE_QVGA;   // 320×240 — fast, enough for colour
  camCfg.jpeg_quality = 12;
  camCfg.fb_count     = 1;
  camCfg.fb_location  = CAMERA_FB_IN_PSRAM;  // N16R8 has 8MB PSRAM
  camCfg.grab_mode    = CAMERA_GRAB_LATEST;

  esp_err_t camErr = esp_camera_init(&camCfg);
  if (camErr != ESP_OK) {
    Serial.printf("[CAM] FATAL: camera init failed (0x%x)\n", camErr);
    // Don't halt — log lux only if camera fails
    Serial.println("[CAM] Continuing with lux-only logging");
  } else {
    // Set camera for sky imaging: auto white balance on, exposure auto
    sensor_t *s = esp_camera_sensor_get();
    s->set_whitebal(s, 1);       // AWB on
    s->set_awb_gain(s, 1);
    s->set_exposure_ctrl(s, 1);  // AEC on
    s->set_aec2(s, 1);           // AEC DSP
    s->set_gain_ctrl(s, 1);      // AGC on
    s->set_brightness(s, 0);
    s->set_contrast(s, 0);
    s->set_saturation(s, 0);
    s->set_special_effect(s, 0); // no filter
    Serial.println("[CAM] OV2640 initialised (RGB565 QVGA)");
  }

  // ── WiFi AP ───────────────────────────────────────────────────────────
  WiFi.mode(WIFI_AP);
  WiFi.softAP(AP_SSID, AP_PASSWORD);
  IPAddress apIP(192, 168, 4, 1);
  WiFi.softAPConfig(apIP, apIP, IPAddress(255, 255, 255, 0));
  Serial.printf("[WiFi] AP: %s  IP: %s\n", AP_SSID, AP_IP);

  // ── mDNS ──────────────────────────────────────────────────────────────
  if (MDNS.begin(MDNS_HOSTNAME)) {
    MDNS.addService("http", "tcp", 80);
    Serial.printf("[mDNS] http://%s.local\n", MDNS_HOSTNAME);
  } else {
    Serial.println("[mDNS] init failed (non-fatal)");
  }

  // ── Web Server Routes ──────────────────────────────────────────────────
  server.on("/",              HTTP_GET,    handleRoot);
  server.on("/api/status",    HTTP_GET,    handleStatus);
  server.on("/api/live",      HTTP_GET,    handleLive);
  server.on("/api/files",     HTTP_GET,    handleFiles);
  server.on("/download",      HTTP_GET,    handleDownload);
  server.on("/api/delete",    HTTP_DELETE, handleDelete);
  server.on("/api/deleteall", HTTP_DELETE, handleDeleteAll);

  // Captive portal — catch all unmatched routes
  server.onNotFound(handleCaptivePortal);

  // Also respond to common captive portal detection URLs
  server.on("/generate_204",          HTTP_GET, handleCaptivePortal); // Android
  server.on("/connecttest.txt",       HTTP_GET, handleCaptivePortal); // Windows
  server.on("/hotspot-detect.html",   HTTP_GET, handleCaptivePortal); // Apple
  server.on("/library/test/success.html", HTTP_GET, handleCaptivePortal); // Apple
  server.on("/ncsi.txt",              HTTP_GET, handleCaptivePortal); // Windows

  server.begin();
  Serial.println("[HTTP] Web server started");
  Serial.println("[HELIOS] Boot complete. Waiting for daylight...");
}

// ═══════════════════════════════════════════════════════════════════════════
//  MAIN LOOP
// ═══════════════════════════════════════════════════════════════════════════
void loop() {
  server.handleClient();
  MDNS.update();

  uint32_t now = millis();
  if (now - lastSampleMs < SAMPLE_INTERVAL_MS) return;
  lastSampleMs = now;

  // ── Read TSL2591 ───────────────────────────────────────────────────────
  float   lux = 0.0f;
  uint8_t gainCode      = 1;
  uint16_t integrationMs = 100;
  readTSL(lux, gainCode, integrationMs);

  // ── Lux-triggered logging state machine ───────────────────────────────
  if (!isLogging && lux >= LUX_START_THRESHOLD) {
    isLogging      = true;
    uptimeStartMs  = now;
    openDayFile(dayCounter);
    Serial.printf("[LOG] Day %lu started — lux=%.1f → %s\n",
      dayCounter + 1, lux, currentFile);
  }

  if (isLogging && lux < LUX_STOP_THRESHOLD) {
    isLogging = false;
    dayCounter++;
    if (dayCounter >= MAX_DAYS) dayCounter = 0;  // wrap (shouldn't happen in 14-day run)
    Serial.printf("[LOG] Day ended — lux=%.1f  total samples: %lu\n",
      lux, totalSamples);
  }

  if (!isLogging) return;

  // ── Read OV2640 blue channel ───────────────────────────────────────────
  uint8_t blue = captureBlueChannel();

  // ── Build sample ───────────────────────────────────────────────────────
  Sample s;
  s.uptime_ms      = now - uptimeStartMs;
  s.lux            = lux;
  s.irradiance_wm2 = lux * LUX_TO_WM2;
  s.blue_channel   = blue;
  s.tsl_gain       = gainCode;
  s.tsl_integration = integrationMs;

  // ── Write to flash ─────────────────────────────────────────────────────
  writeSample(s);
  pushToLiveBuffer(s);

  Serial.printf("[SAMPLE] t=%lums  lux=%.1f  irr=%.3fW/m²  blue=%u  gain=%u\n",
    s.uptime_ms, s.lux, s.irradiance_wm2, s.blue_channel, s.tsl_gain);
}
